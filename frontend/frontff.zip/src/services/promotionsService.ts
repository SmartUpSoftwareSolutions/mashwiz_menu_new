import { supabase } from '@/integrations/supabase/client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

export interface Promotion {
  id: string;
  title: string | null;
  image_url: string;
  amount: string | null;
  date_from: string;
  date_to: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export const fetchActivePromotions = async (): Promise<Promotion[]> => {
  const today = new Date().toISOString().split('T')[0];
  const { data, error } = await supabase
    .from('promotions')
    .select('*')
    .eq('is_active', true)
    .lte('date_from', today)
    .gte('date_to', today)
    .order('created_at', { ascending: false });

  if (error) throw error;
  return data || [];
};

export const fetchAllPromotions = async (): Promise<Promotion[]> => {
  const { data, error } = await supabase
    .from('promotions')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) throw error;
  return data || [];
};

export const createPromotion = async (
  promotion: Omit<Promotion, 'id' | 'created_at' | 'updated_at'>
): Promise<Promotion> => {
  const { data, error } = await supabase
    .from('promotions')
    .insert(promotion)
    .select()
    .single();
  if (error) throw error;
  return data;
};

export const updatePromotion = async (
  id: string,
  promotion: Partial<Omit<Promotion, 'id' | 'created_at' | 'updated_at'>>
): Promise<Promotion> => {
  const { data, error } = await supabase
    .from('promotions')
    .update({ ...promotion, updated_at: new Date().toISOString() })
    .eq('id', id)
    .select()
    .single();
  if (error) throw error;
  return data;
};

export const deletePromotion = async (id: string): Promise<void> => {
  const { error } = await supabase.from('promotions').delete().eq('id', id);
  if (error) throw error;
};

export const useActivePromotions = () =>
  useQuery({ queryKey: ['promotions', 'active'], queryFn: fetchActivePromotions, staleTime: 1000 * 60 * 5 });

export const useAllPromotions = () =>
  useQuery({ queryKey: ['promotions', 'all'], queryFn: fetchAllPromotions });

export const useCreatePromotion = () => {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: createPromotion,
    onSuccess: () => qc.invalidateQueries({ queryKey: ['promotions'] }),
  });
};

export const useUpdatePromotion = () => {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<Omit<Promotion, 'id' | 'created_at' | 'updated_at'>> }) =>
      updatePromotion(id, data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['promotions'] }),
  });
};

export const useDeletePromotion = () => {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: deletePromotion,
    onSuccess: () => qc.invalidateQueries({ queryKey: ['promotions'] }),
  });
};
