import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export interface PublicBranch {
  code: string;
  name: string;
  name_ar?: string | null;
  address?: string;
  city?: string;
}

const normalizeBranchCode = (value: unknown): string | null => {
  if (typeof value !== "string") return null;
  const trimmed = value.trim();
  return trimmed.length > 0 ? trimmed : null;
};

const dedupeBranches = (branches: PublicBranch[]): PublicBranch[] => {
  const seen = new Set<string>();
  return branches.filter((b) => {
    const code = b.code.trim();
    if (seen.has(code)) return false;
    seen.add(code);
    return true;
  });
};

/**
 * Primary source: `branches` table — explicit code → name mapping.
 */
const fetchBranchesFromBranchesTable = async (): Promise<PublicBranch[]> => {
  const { data, error } = await supabase
    .from("branches")
    .select("code, name, name_ar")
    .order("name", { ascending: true });

  if (error) throw error;

  return ((data ?? []) as unknown as Array<{ code: string | null; name: string | null; name_ar: string | null }>)
    .map((row) => {
      const code = normalizeBranchCode(row.code);
      if (!code) return null;
      return { code, name: row.name || code, name_ar: row.name_ar ?? null };
    })
    .filter(Boolean) as PublicBranch[];
};

/**
 * Secondary source: `locations` table with branch_code column.
 */
const fetchBranchesFromLocations = async (): Promise<PublicBranch[]> => {
  const { data, error } = await supabase
    .from("locations")
    .select("branch_code, name, address, city")
    .not("branch_code", "is", null)
    .order("name", { ascending: true });

  if (error) throw error;

  const branches: PublicBranch[] = [];
  const seen = new Set<string>();

  for (const loc of data ?? []) {
    const code = normalizeBranchCode(loc.branch_code);
    if (code && !seen.has(code)) {
      seen.add(code);
      branches.push({
        code,
        name: loc.name || code,
        address: loc.address ?? undefined,
        city: loc.city ?? undefined,
      });
    }
  }

  return branches;
};

/**
 * Last resort: distinct branch_code values from item_master.
 * Names will just be the codes — user should populate the branches table.
 */
const fetchBranchesFromItems = async (): Promise<PublicBranch[]> => {
  const { data, error } = await supabase
    .from("item_master")
    .select("branch_code")
    .not("branch_code", "is", null);

  if (error) throw error;

  const seen = new Set<string>();
  const branches: PublicBranch[] = [];

  for (const row of data ?? []) {
    const code = normalizeBranchCode(row.branch_code);
    if (code && !seen.has(code)) {
      seen.add(code);
      branches.push({ code, name: code });
    }
  }

  return branches;
};

export const fetchMenuBranches = async (): Promise<PublicBranch[]> => {
  // 1. branches table (explicit name mapping)
  try {
    const branches = await fetchBranchesFromBranchesTable();
    if (branches.length > 0) return dedupeBranches(branches);
  } catch {
    // table may not exist yet — fall through
  }

  // 2. locations table with branch_code column
  try {
    const branches = await fetchBranchesFromLocations();
    if (branches.length > 0) return dedupeBranches(branches);
  } catch {
    // column may not exist yet — fall through
  }

  // 3. item_master branch codes (codes only, no names)
  try {
    const branches = await fetchBranchesFromItems();
    if (branches.length > 0) return dedupeBranches(branches);
  } catch {
    // ignore
  }

  return [];
};

export const useMenuBranches = () =>
  useQuery({
    queryKey: ["menuBranches"],
    queryFn: fetchMenuBranches,
    staleTime: 1000 * 60 * 5,
  });
